﻿Imports System.IO.Ports
Imports MySql.Data.MySqlClient

Public Class Form1

    Dim connection As Boolean = False
    Dim scr As Boolean = False
    Dim host, user, pass, db, query As String
    Dim conn As MySqlConnection = New MySqlConnection()
    Dim field As String

    Private Sub GetSerialPortNames()

        For Each sport As String In My.Computer.Ports.SerialPortNames

            comPort.Items.Add(sport)

        Next

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs)

        close_port()
        mysql_close()

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        GetSerialPortNames()
        btnSend.Enabled = False
        txtOut.Enabled = False
        comBaud.SelectedIndex = 4
        CheckBox1.Checked = True
        host = ""
        user = ""
        pass = ""
        db = ""
        query = ""

    End Sub

    Private Sub btnToggle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToggle.Click

        If connection Then

            close_port()

        Else

            open_port()

        End If

    End Sub

    Private Sub close_port()

        If com.IsOpen() Then

            Try

                com.Close()
                connection = False
                btnToggle.Text = "Connect"
                comPort.Enabled = True
                btnSend.Enabled = False
                txtOut.Enabled = False
                Exit Sub

            Catch

                MessageBox.Show("Some kind of problem.")

            End Try

        End If

    End Sub

    Private Sub open_port()

        Try

            com.BaudRate = comBaud.SelectedItem
            com.PortName = comPort.SelectedItem.ToString
            com.Parity = Parity.None
            com.DataBits = 8
            com.StopBits = StopBits.One
            com.DtrEnable = True
            com.Open()

            If com.IsOpen Then

                connection = True
                comPort.Enabled = False
                txtOut.Enabled = True
                btnSend.Enabled = True
                btnToggle.Text = "Disconnect"

            End If

        Catch

            com.Close()
            btnToggle.Text = "Connect"

        End Try

    End Sub

    Private Sub comBaud_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles comBaud.SelectedIndexChanged

        close_port()
        open_port()

    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click

        If txtOut.TextLength > 0 Then

            com.Write(txtOut.Text)
            send_data(txtOut.Text)

        End If

    End Sub

    Private Sub txtOut_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtOut.KeyDown

        If txtOut.TextLength > 0 Then

            If e.KeyCode = Keys.Enter Then

                send_data(txtOut.Text)
                txtOut.Clear()

            End If

        End If

    End Sub

    Private Sub send_data(ByVal str As String)

        If str.Contains("host=") Then

            host = str.Replace("host=", "")

        ElseIf str.Contains("user=") Then

            user = str.Replace("user=", "")

        ElseIf str.Contains("pass=") Then

            pass = str.Replace("pass=", "")

        ElseIf str.Contains("db=") Then

            db = str.Replace("db=", "")

        ElseIf str = "mysql_close()" Then

            mysql_close()

        ElseIf str = "mysql_connect()" Then

            mysql_connect()

        ElseIf str.Contains("query=") Then

            If str.Contains("&field=") Then

                field = str.Remove(0, str.IndexOf("&"))
                field = field.Replace("&field=", "")
                query = str.Replace("query=", "")
                query = query.Replace("&field=" + field, "")
                mysql_result(field)

            ElseIf str.Contains("count(") Then

                query = str.Replace("query=", "")
                mysql_count()

            Else

                query = str.Replace("query=", "")
                mysql_query()

            End If
        ElseIf str.Contains("is_mysql()") Then

            is_mysql()

        End If

        ShowString(str)

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        scr = CheckBox1.CheckState

    End Sub

    Private Sub mysql_connect()

        If conn.State Then
            conn.Close()
        End If

        conn.ConnectionString = "server=" & host & ";user id=" & user & ";password=" & pass & ";database=" & db

        Try

            conn.Open()
            show_server("Connected")
            com.Write(1)
            ' ShowString(1)

        Catch myerror As MySqlException
            ' ShowString("-")
            com.Write("-")
            ShowString(myerror.Message)
        End Try


    End Sub

    Private Sub is_mysql()

        If conn.State Then
            com.Write(1)
            ' ShowString(1)
        Else
            com.Write("-")
            '  ShowString("-")
        End If

    End Sub
    Private Sub mysql_close()

        If conn.State Then

            Try

                conn.Close()
                show_server("Disconnected")

            Catch myerror As MySqlException

                ' ShowString(myerror.Message)

            End Try

        End If

    End Sub

    Private Sub mysql_query()

        If conn.State Then
            com.Write("")
            Dim command As New MySqlCommand
            command = New MySqlCommand(query)
            command.Connection = conn

            Try
                command.ExecuteScalar()
                com.Write(1)
                '  ShowString(1)

            Catch e As MySqlException

                com.Write("-")
                ' ShowString("-")
                ShowString(e.Message)
            End Try

        End If


    End Sub

    Private Sub mysql_count()

        If conn.State Then

            Dim command As New MySqlCommand
            command = New MySqlCommand(query)
            command.Connection = conn

            Try

                Dim x As Integer = command.ExecuteScalar
                command = Nothing
                com.Write(x.ToString)
                '  ShowString(x.ToString)
            Catch e As MySqlException
                com.Write("-")
                ' ShowString("-")
                ShowString(e.Message)
            End Try

        End If

    End Sub

    Private Sub mysql_result(ByVal f As String)

        If conn.State Then

            Dim command As New MySqlCommand
            command = New MySqlCommand(query)
            command.Connection = conn

            Try

                Dim str As String
                Dim x As MySqlDataReader = command.ExecuteReader
                x.Read()
                str = x(f).ToString
                command = Nothing
                x.Close()
                com.Write(str)
                '  ShowString(str)
            Catch e As MySqlException
                ' ShowString("-")
                com.Write("-")

            End Try

        End If

    End Sub

    Private Sub com_DataReceived(ByVal sender As System.Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles com.DataReceived

        send_data(com.ReadLine().Replace(vbCr, "").Replace(vbLf, ""))

    End Sub
    Private Delegate Sub AppendTextBoxDelegate(ByVal txt As String)

    Private Sub ShowString(ByVal txt As String)

        If txtIn.InvokeRequired Then
            txtIn.Invoke(New AppendTextBoxDelegate(AddressOf ShowString), New Object() {txt})
        Else
            txtIn.AppendText(txt + vbNewLine)
        End If

    End Sub
    Private Delegate Sub Appendlabel(ByVal txt As String)

    Private Sub show_server(ByVal txt As String)

        If Label1.InvokeRequired Then
            Label1.Invoke(New AppendTextBoxDelegate(AddressOf show_server), New Object() {txt})
        Else
            Label1.Text = txt
        End If

    End Sub

End Class
