﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnToggle = New System.Windows.Forms.Button()
        Me.comPort = New System.Windows.Forms.ComboBox()
        Me.comBaud = New System.Windows.Forms.ComboBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.btnSend = New System.Windows.Forms.Button()
        Me.com = New System.IO.Ports.SerialPort(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtIn = New System.Windows.Forms.RichTextBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnToggle
        '
        Me.btnToggle.Location = New System.Drawing.Point(180, 13)
        Me.btnToggle.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnToggle.Name = "btnToggle"
        Me.btnToggle.Size = New System.Drawing.Size(85, 24)
        Me.btnToggle.TabIndex = 0
        Me.btnToggle.Text = "Connect"
        Me.btnToggle.UseVisualStyleBackColor = True
        '
        'comPort
        '
        Me.comPort.FormattingEnabled = True
        Me.comPort.Location = New System.Drawing.Point(12, 13)
        Me.comPort.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.comPort.Name = "comPort"
        Me.comPort.Size = New System.Drawing.Size(72, 24)
        Me.comPort.TabIndex = 2
        '
        'comBaud
        '
        Me.comBaud.FormattingEnabled = True
        Me.comBaud.Items.AddRange(New Object() {"300", "1200", "2400", "4800", "9600", "14400", "19200", "28800", "38400", "57600", "115200"})
        Me.comBaud.Location = New System.Drawing.Point(105, 13)
        Me.comBaud.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.comBaud.Name = "comBaud"
        Me.comBaud.Size = New System.Drawing.Size(69, 24)
        Me.comBaud.TabIndex = 3
        '
        'txtOut
        '
        Me.txtOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOut.Location = New System.Drawing.Point(12, 44)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(196, 23)
        Me.txtOut.TabIndex = 5
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(214, 44)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(51, 23)
        Me.btnSend.TabIndex = 6
        Me.btnSend.Text = "Send"
        Me.btnSend.UseVisualStyleBackColor = True
        '
        'com
        '
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Location = New System.Drawing.Point(-5, 308)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(272, 32)
        Me.Panel1.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(141, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Server:Disconnected"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(8, 3)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(83, 20)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Autoscroll"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.txtOut)
        Me.Panel2.Controls.Add(Me.btnSend)
        Me.Panel2.Controls.Add(Me.comPort)
        Me.Panel2.Controls.Add(Me.comBaud)
        Me.Panel2.Controls.Add(Me.btnToggle)
        Me.Panel2.Location = New System.Drawing.Point(-9, -4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(276, 72)
        Me.Panel2.TabIndex = 8
        '
        'txtIn
        '
        Me.txtIn.BackColor = System.Drawing.Color.White
        Me.txtIn.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtIn.Location = New System.Drawing.Point(0, 67)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.ReadOnly = True
        Me.txtIn.Size = New System.Drawing.Size(263, 243)
        Me.txtIn.TabIndex = 9
        Me.txtIn.Text = ""
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(260, 332)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.txtIn)
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "Serial Port"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnToggle As System.Windows.Forms.Button
    Friend WithEvents comPort As System.Windows.Forms.ComboBox
    Friend WithEvents comBaud As System.Windows.Forms.ComboBox
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents com As System.IO.Ports.SerialPort
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents txtIn As System.Windows.Forms.RichTextBox
End Class
